/*
 * Copyright (c) 2018-2019 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/CANAnalog.h"

#include "rev/CANSparkMax.h"
#include "rev/CANSparkMaxDriver.h"

using namespace rev;

CANAnalog::CANAnalog(CANSparkMax& device, AnalogMode mode) : CANSensor(device), m_mode(mode) {
    c_SparkMax_SetAnalogMode(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), static_cast<c_SparkMax_AnalogMode>(mode));
}

double CANAnalog::GetPosition() {
    float tmp;
    c_SparkMax_GetAnalogPosition(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANAnalog::GetVelocity() {
    float tmp;
    c_SparkMax_GetAnalogVelocity(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANAnalog::GetVoltage() {
    float tmp;
    c_SparkMax_GetAnalogVoltage(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

CANError CANAnalog::SetPositionConversionFactor(double factor) {
    auto status = c_SparkMax_SetAnalogPositionConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), factor);
    return static_cast<CANError>(status);
}

double CANAnalog::GetPositionConversionFactor() {
    float tmp;
    c_SparkMax_GetAnalogPositionConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

CANError CANAnalog::SetVelocityConversionFactor(double factor) {
    auto status = c_SparkMax_SetAnalogVelocityConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), factor);
    return static_cast<CANError>(status);
}

double CANAnalog::GetVelocityConversionFactor() {
    float tmp;
    c_SparkMax_GetAnalogVelocityConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

int CANAnalog::GetID() const {
    return static_cast<uint32_t>(FeedbackSensorType::kAnalog);
}

CANError CANAnalog::SetInverted(bool inverted)  {
    auto status = c_SparkMax_SetAnalogInverted(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), inverted);
    return static_cast<CANError>(status);
}

bool CANAnalog::GetInverted() const {
    uint8_t inverted;
    c_SparkMax_GetAnalogInverted(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &inverted);
    return inverted ? true : false; 
}

CANError CANAnalog::SetAverageDepth(uint32_t depth) {
    auto status = c_SparkMax_SetAnalogAverageDepth(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), depth);
    return static_cast<CANError>(status);
}

CANError CANAnalog::SetMeasurementPeriod(uint32_t period_ms) {
    auto status = c_SparkMax_SetAnalogMeasurementPeriod(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), period_ms);
    return static_cast<CANError>(status);
}

uint32_t CANAnalog::GetAverageDepth() {
    uint32_t depth = 0;
    c_SparkMax_GetAnalogAverageDepth(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &depth);
    return depth;
}

uint32_t CANAnalog::GetMeasurementPeriod() {
    uint32_t period_ms = 0;
    c_SparkMax_GetAnalogMeasurementPeriod(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &period_ms);
    return period_ms;
}
