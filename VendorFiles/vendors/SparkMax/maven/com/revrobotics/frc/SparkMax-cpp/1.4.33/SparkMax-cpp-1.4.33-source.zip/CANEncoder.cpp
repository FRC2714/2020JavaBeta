/*
 * Copyright (c) 2018-2019 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/CANEncoder.h"

#include "rev/CANSparkMaxDriver.h"
#include "rev/CANSparkMax.h"

using namespace rev;

CANEncoder::CANEncoder(CANSparkMax& device, EncoderType sensorType, int cpr) 
    : CANSensor(device), m_sensorType(sensorType) {
    // Unhandled CANError is returned by the c_SparkMax_SetSensorType and c_SparkMax_SetCPR calls
    if (!encInitialized || m_cpr != cpr) {
        encInitialized = true;
        m_cpr = cpr;
        c_SparkMax_SetSensorType(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), static_cast<c_SparkMax_EncoderType>(m_sensorType));
        // Don't set the CPR if the sensorType is a kHallEffect or cpr = 0
        if (!(sensorType == EncoderType::kHallSensor || m_cpr == 0)) {
            c_SparkMax_SetCPR(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), m_cpr);
        }
    }
}

CANEncoder::CANEncoder(CANEncoder&& rhs) : CANSensor(std::move(rhs)),
    m_sensorType(std::move(rhs.m_sensorType)),
    m_cpr(std::move(rhs.m_cpr)),
    encInitialized(rhs.encInitialized.load()) {}

CANEncoder& CANEncoder::operator=(CANEncoder&& rhs) {
  CANSensor::operator=(std::move(rhs));

  m_device = std::move(rhs.m_device);
  m_sensorType = std::move(rhs.m_sensorType);
  m_cpr = std::move(rhs.m_cpr);
  encInitialized = rhs.encInitialized.load();

  return *this;
}

double CANEncoder::GetPosition() {
    float tmp;
    c_SparkMax_GetEncoderPosition(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANEncoder::GetVelocity() {
    float tmp;
    c_SparkMax_GetEncoderVelocity(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

CANError CANEncoder::SetPosition(double position) {
    auto status = c_SparkMax_SetEncoderPosition(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), position);
    return static_cast<CANError>(status);
}

CANError CANEncoder::SetPositionConversionFactor(double factor) {
    auto status = c_SparkMax_SetPositionConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), factor);
    return static_cast<CANError>(status);
}

CANError CANEncoder::SetVelocityConversionFactor(double factor) {
    auto status = c_SparkMax_SetVelocityConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), factor);
    return static_cast<CANError>(status);
}

double CANEncoder::GetPositionConversionFactor() {
    float tmp;
    c_SparkMax_GetPositionConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

double CANEncoder::GetVelocityConversionFactor() {
    float tmp;
    c_SparkMax_GetVelocityConversionFactor(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

CANError CANEncoder::SetAverageDepth(uint32_t depth) {
    auto status = c_SparkMax_SetAverageDepth(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), depth);
    return static_cast<CANError>(status);
}

uint32_t CANEncoder::GetAverageDepth() {
    uint32_t tmp;
    c_SparkMax_GetAverageDepth(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<uint32_t>(tmp);
}

CANError CANEncoder::SetMeasurementPeriod(uint32_t samples) {
    auto status = c_SparkMax_SetMeasurementPeriod(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), samples);
    return static_cast<CANError>(status);
}

uint32_t CANEncoder::GetMeasurementPeriod() {
    uint32_t tmp;
    c_SparkMax_GetMeasurementPeriod(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<uint32_t>(tmp);
}

uint32_t CANEncoder::GetCPR() {
    uint32_t tmp;
    c_SparkMax_GetCPR(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<uint32_t>(tmp);
}

int CANEncoder::GetID() const {
    return static_cast<uint32_t>((static_cast<c_SparkMax_MotorType>(m_device->GetInitialMotorType()) == c_SparkMax_kBrushless)
        ? FeedbackSensorType::kHallSensor : FeedbackSensorType::kQuadrature);
}

CANError CANEncoder::SetInverted(bool inverted)  {
    if (static_cast<c_SparkMax_MotorType>(m_device->GetInitialMotorType()) == c_SparkMax_kBrushless) {
        throw std::invalid_argument("Not available in Brushless Mode");
    } 

    auto status = c_SparkMax_SetEncoderInverted(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), inverted);
    return static_cast<CANError>(status);
}

bool CANEncoder::GetInverted() const {
    uint8_t inverted;
    c_SparkMax_GetEncoderInverted(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &inverted);
    return inverted ? true : false; 
}
